
package laboratorio2018;

/**
 *
 * @author Laly
 */
public class SistemaEmergencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
       
            
        
    }
    
}
