/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio2018;

import java.time.Duration;
import java.time.LocalDateTime;
/**
 *
 * @author Laly
 */
public class PagoAfiliado {
    
    private int importe;
    private LocalDateTime fechainiciopago;
    private LocalDateTime fechafinalpago;
    
    PagoAfiliado(LocalDateTime fechainiciopago, LocalDateTime fechafinalpago){
        
        this.fechainiciopago=fechainiciopago;
        this.fechafinalpago=fechafinalpago;
    }
    
    public long fechas(LocalDateTime fechainiciopago, LocalDateTime fechafinalpago) {
        
        long resultado = Duration.between( fechainiciopago,fechafinalpago).toHours();
     
        return resultado;
    }
    
    
}
