
package laboratorio2018;


public abstract class Persona {
    
    public String nombre;
    public String apellido;
    private String domicilio;
    private int fechaNacimiento;
    
    public Persona( String nombre, String apellido, String domicilio , int fechaNacimiento){
        
        this.nombre= nombre;
        this.apellido= apellido;
        this.domicilio= domicilio;
        this.fechaNacimiento= fechaNacimiento;
    }
    
    public String getNombre(){
        
        return nombre;
    }
    
    public String getApellido(){
        
        return apellido;
    }
    
    private String getDocimilio(){
        
        return domicilio;
    }
    
    private int getfechaNacimiento(){
        
        return fechaNacimiento;
    }
    
    
    
    
    
    
    
    
    
}
