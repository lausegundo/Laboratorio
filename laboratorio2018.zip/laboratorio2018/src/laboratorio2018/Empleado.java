
package laboratorio2018;


public class Empleado extends Persona {
    
    private int numlegajo;
   
    
    public Empleado (String nombre, String apellido, String domicilio , int fechaNacimiento, int numlegajo ){
        
        super (nombre, apellido, domicilio, fechaNacimiento);
        this.numlegajo= numlegajo;
        
    }
    
   private int getNumlegajo(){
        
        return numlegajo;
    }
    
    }
    
  