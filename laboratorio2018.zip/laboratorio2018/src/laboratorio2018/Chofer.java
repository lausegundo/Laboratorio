
package laboratorio2018;

/**
 *
 * @author Laly
 */
public class Chofer extends Empleado{
    
   public Chofer (String nombre, String apellido, String domicilio , int fechaNacimiento, int numlegajo){
   
     
        
        super (nombre, apellido, domicilio,numlegajo,fechaNacimiento);
        
      
       
}
    
    
    
}
