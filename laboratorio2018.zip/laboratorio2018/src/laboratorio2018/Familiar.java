/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorio2018;

/**
 *
 * @author Laly
 */
public class Familiar extends Persona{
    
    private String parentesco;
    
    public Familiar (String nombre, String apellido, String domicilio , int fechaNacimiento){
        
        super (nombre, apellido, domicilio,fechaNacimiento);
       
        this.parentesco = parentesco;
    }
    
    private String getParentesco(){
        
        return parentesco;
    }
    
    
    
}
